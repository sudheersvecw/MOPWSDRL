package org.workflowsim.examples.scheduling;

import java.util.Arrays;
import java.util.Random;

public class ACO {

    static int numOfCities = 50; // Number of cities
    static int numOfAnts = 100; // Number of ants
    static int maxIterations = 100; // Maximum number of iterations
    static double alpha = 1.0; // Alpha parameter
    static double beta = 2.0; // Beta parameter
    static double evaporationRate = 0.5; // Evaporation rate
    static double pheromone[][] = new double[numOfCities+10][numOfCities+10]; // Pheromone matrix
    static double distance[][] = new double[numOfCities+10][numOfCities+10]; // Distance matrix
    static Ant ants[] = new Ant[numOfAnts]; // Array of ants

    static class Ant {
        int tour[] = new int[numOfCities];
        boolean visited[] = new boolean[numOfCities];
        int tourLength = 0;
    }

    public static void main(String[] args) {
        initialize(); // Initialize pheromone and distance matrices

        for (int i = 0; i < maxIterations; i++) {
            generateAnts(); // Generate ant tours
            updatePheromone(); // Update pheromone levels
        }

        // Display the best tour found by the ants
        Ant bestAnt = getBestAnt();
        System.out.println("Best tour: " + Arrays.toString(bestAnt.tour));
        System.out.println("Tour length: " + bestAnt.tourLength);
    }

    // Initialize pheromone and distance matrices
    static void initialize() {
        Random rand = new Random();
        try {
        for (int i = 0; i < numOfCities; i++) {
            for (int j = 0; j < numOfCities; j++) {
                if (i != j) {
                    pheromone[i][j] = 1.0; // Initial pheromone level
                    distance[i][j] = rand.nextInt(100) + 1; // Random distance between cities
                }
            }
        }
        }
        
    
        catch(Exception e) {
        }
    }
    

    // Generate ant tours
    static void generateAnts() {
    	try {
        for (int k = 0; k < numOfAnts; k++) {
            Ant ant = new Ant();
            ant.tour[0] = 0; // Start from city 0
            ant.visited[0] = true;

            for (int i = 1; i < numOfCities; i++) {
                int nextCity = selectNextCity(ant);
                ant.tour[i] = nextCity;
                ant.visited[nextCity] = true;
                ant.tourLength += distance[ant.tour[i - 1]][ant.tour[i]];
            }

            // Return to the starting city
            ant.tourLength += distance[ant.tour[numOfCities - 1]][ant.tour[0]];
            ants[k] = ant;
        }
    	}
    	catch(Exception e) {}
    }

    // Select the next city for an ant
    static int selectNextCity(Ant ant) {
        int currentCity = ant.tour[ant.tourLength == 0 ? 0 : ant.tourLength / (numOfCities - 1)];
        double[] probabilities = new double[numOfCities];
        double totalProbability = 0.0;

        for (int i = 0; i < numOfCities; i++) {
            if (!ant.visited[i]) {
                probabilities[i] = Math.pow(pheromone[currentCity][i], alpha) * Math.pow(1.0 / distance[currentCity][i], beta);
                totalProbability += probabilities[i];
            }
        }

        double rand = Math.random() * totalProbability;
        double sum = 0.0;

        for (int i = 0; i < numOfCities; i++) {
            if (!ant.visited[i]) {
                sum += probabilities[i];
                if (sum >= rand) {
                    return i;
                }
            }
        }
        return -1;
    }

    // Update pheromone levels
    static void updatePheromone() {
        for (int i = 0; i < numOfCities; i++) {
            for (int j = 0; j < numOfCities; j++) {
                if (i != j) {
                    pheromone[i][j] *= (1.0 - evaporationRate); // Evaporation
                    for (Ant ant : ants) {
                        pheromone[i][j] += (ant.visited[i] && ant.visited[j]) ? (1.0 / ant.tourLength) : 0.0;
                    }
                }
            }
        }
    }

    // Get the best ant (tour with the shortest length)
    static Ant getBestAnt() {
        Ant bestAnt = ants[0];
        for (Ant ant : ants) {
            if (ant.tourLength < bestAnt.tourLength) {
                bestAnt = ant;
            }
        }
        return bestAnt;
    }
}
